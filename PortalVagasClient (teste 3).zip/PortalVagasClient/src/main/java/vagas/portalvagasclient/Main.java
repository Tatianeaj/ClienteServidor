package vagas.portalvagasclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.UUID;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;

public class Main {
    private static boolean isLoggedIn = false;

    public static void main(String[] args) {
        BufferedReader tc = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Digite o IP do servidor:");
        String IP_SERVIDOR = null;
        try {
            IP_SERVIDOR = tc.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erro ao ler o IP do servidor. Saindo...");
            System.exit(1);
        }
        final int PORTA_SERVIDOR = 22222;


        try (Socket socket = new Socket(IP_SERVIDOR, PORTA_SERVIDOR);
             BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter saida = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in))) {
            String userType;
            do {
                System.out.println("Digite o tipo de usuário (1 para candidato, 2 para empresa):");
                userType = teclado.readLine();
            } while (!userType.equals("1") && !userType.equals("2"));

            String opcao;
            if (userType.equals("1")) {
                System.out.println("Escola [1] para fazer login ou [2] para se cadastrar como candidato:");
                while ((opcao = teclado.readLine()) != null) {
                    switch (opcao) {
                        case "1":
                            loginCandidato(saida, teclado, entrada);
                            break;
                        case "2":
                            cadastrarCandidato(saida, teclado);
                            break;
                        default:
                            System.out.println("Opção inválida. Digite novamente.");
                    }
                }
                //System.out.println("Conectado ao servidor. Digite uma opção:");
                //System.out.println("1. Consultar candidato");
                //System.out.println("2. Cadastrar candidato");
                // System.out.println("3. Login");
                //System.out.println("4. Atualizar candidato");
                //System.out.println("5. Apagar candidato");
                //System.out.println("6. Logout");
                //System.out.println("7. Sair");
            } else if (userType.equals("2")) {
                System.out.println("Escola [1] para fazer login ou [2] para se cadastrar como empresa:");
                while ((opcao = teclado.readLine()) != null) {
                    switch (opcao) {
                        case "1":
                            loginEmpresa(saida, teclado, entrada);
                            break;
                        case "2":
                            cadastrarEmpresa(saida, teclado);
                            break;
                        default:
                            System.out.println("Opção inválida. Digite novamente.");
                    }
                }
                // System.out.println("Conectado ao servidor. Digite uma opção:");
                // System.out.println("1. Consultar empresa");
                //System.out.println("2. Cadastrar empresa");
                //System.out.println("3. Login");
                //System.out.println("4. Atualizar empresa");
                //System.out.println("5. Apagar empresa");
                //System.out.println("6. Logout");
                //System.out.println("7. Sair");
                // Adicione aqui as opções do menu para empresas
            }


            //String opcao;
            // if (userType.equals("1")) {
            if (isLoggedIn && "1".equals(userType)) {

                // System.out.println("Conectado ao servidor. Digite uma opção:");
                System.out.println("1. Meus Dados(Consultar candidato)");
                System.out.println("2. Cadastrar competencias/experiências");
                System.out.println("3. Consultar minhas competencias/experiências");
                System.out.println("4. Atualizar minhas competencias/experiências");
                System.out.println("5. Deletar minhas competencias/experiências");
                System.out.println("6. Alterar meus dados(Atualizar candidato)");
                System.out.println("7. Deletar meu cadastro(Apagar candidato)");
                System.out.println("8. Pesquisa filtrada");
                System.out.println("9. Logout");
                //System.out.println("7. Sair");

                while ((opcao = teclado.readLine()) != null) {
                    switch (opcao) {
                        case "1":
                            visualizarCandidato(saida, teclado);
                            break;
                        case "2":
                            //     cadastrarCandidato(saida, teclado);
                            cadastrarCompetenciaExperiencia(saida, teclado);
                            break;
                        case "3":
                            visualizarCompetenciaExperiencia(saida, teclado);
                            break;
                        //   loginCandidato(saida, teclado, entrada);
                        case "4":
                            atualizarCompetenciaExperiencia(saida, teclado);
                            break;
                        // atualizarCandidato(saida, teclado);
                        case "5":
                            apagarCompetenciaExperiencia(saida, teclado);
                            //apagarCandidato(saida, teclado);
                            break;
                        case "6":
                            atualizarCandidato(saida, teclado);
                            //apagarCandidato(saida, teclado);
                            break;
                        case "7":
                            apagarCandidato(saida, teclado, entrada);
                            //System.out.println("Saindo...");
                            //System.exit(0);
                            break;
                        case "8":
                            listarVagas(saida, teclado);
                            break;
                        case "9":
                            isLoggedIn = false;
                            userType = "0";
                            logout(saida);

                            break;

                        default:
                            System.out.println("Opção inválida. Digite novamente.");
                    }

                     saida.flush();

                    String resposta = entrada.readLine();
                    System.out.println("Resposta do servidor: " + resposta);
                }
            } else {//aqui
                System.out.println("1. Meus Dados(Consultar empresa)");
                System.out.println("2. Cadastrar vagas");
                System.out.println("3. Consultar minhas vagas");
                System.out.println("4. Atualizar minhas vagas");
                System.out.println("5. Deletar minhas vagas");
                System.out.println("6. Alterar meus dados(Atualizar empresa)");
                System.out.println("7. Deletar meu cadastro(Apagar empresa)");
                System.out.println("8. Listar Vagas");
                System.out.println("9. Pesquisa filtrada");
                System.out.println("10. Logout");

                while ((opcao = teclado.readLine()) != null) {
                    switch (opcao) {
                        case "1":
                            visualizarEmpresa(saida, teclado);
                            break;
                        case "2":
                            //cadastrarEmpresa(saida, teclado);
                            cadastrarVaga(saida, teclado);
                            break;
                        case "3":
                            //loginEmpresa(saida, teclado, entrada);
                            visualizarVaga(saida, teclado);
                            break;
                        case "4":
                            //atualizarEmpresa(saida, teclado);
                            atualizarVaga(saida, teclado);
                            break;
                        case "5":
                            //apagarEmpresa(saida, teclado);
                            apagarVaga(saida, teclado);
                            break;
                        case "6":
                            atualizarEmpresa(saida, teclado);
                            break;
                        case "7":
                            apagarEmpresa(saida, teclado, entrada);
                            break;
                        case "8":
                            listarVagas(saida, teclado);
                            break;
                        case "9":
                            filtrarVagas(saida, teclado);
                            break;
                        case "10":
                            isLoggedIn = false;
                            userType = "0";
                            logout(saida);
                            break;
                        default:
                            System.out.println("Opção inválida. Digite novamente.");
                    }

                    // saida.flush();

                    String resposta = entrada.readLine();
                    System.out.println("Resposta do servidor: " + resposta);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static String criarMensagemJSON(String... args) {
        JsonObject json = new JsonObject();
        for (int i = 0; i < args.length; i += 2) {
            json.addProperty(args[i], args[i + 1]);
        }
        return json.toString();
    }


    private static void cadastrarCandidato(PrintWriter saida, BufferedReader teclado) throws IOException {
        System.out.println("Digite o nome de usuário:");
        String nome = teclado.readLine();
        System.out.println("Digite o email do usuário:");
        String email = teclado.readLine();
        System.out.println("Digite a senha:");
        String senha = teclado.readLine();
        saida.println(criarMensagemJSON("operacao", "cadastrarCandidato", "nome", nome, "email", email, "senha", senha));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "cadastrarCandidato", "nome", nome, "email", email, "senha", senha));
        saida.flush();
    }


    private static void cadastrarEmpresa(PrintWriter saida, BufferedReader teclado) throws IOException {
        System.out.println("Digite a razão social:");
        String razaoSocial = teclado.readLine();
        System.out.println("Digite o email da empresa:");
        String email = teclado.readLine();
        System.out.println("Digite o cnpj:");
        String cnpj = teclado.readLine();
        System.out.println("Digite a senha:");
        String senha = teclado.readLine();
        System.out.println("Digite a descricao:");
        String descricao = teclado.readLine();
        System.out.println("Digite o ramo:");
        String ramo = teclado.readLine();


        saida.println(criarMensagemJSON("operacao", "cadastrarEmpresa",
                "razaoSocial", razaoSocial,
                "email", email, "cnpj", cnpj, "senha", senha,
                "descricao", descricao, "ramo", ramo));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "cadastrarEmpresa",
                "razaoSocial", razaoSocial,
                "email", email, "cnpj", cnpj, "senha", senha,
                "descricao", descricao, "ramo", ramo));
        saida.flush();
    }


    private static void cadastrarCompetenciaExperiencia(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email do usuário:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        JsonArray competenciaExperienciaArray = new JsonArray();
        String continuar;

        do {
            JsonObject competenciaExperiencia = new JsonObject();
            System.out.println("Digite a competencia:");
            String competencia = teclado.readLine();
            competenciaExperiencia.addProperty("competencia", competencia);

            System.out.println("Digite a experiencia:");
            int experiencia = Integer.parseInt(teclado.readLine());
            competenciaExperiencia.addProperty("experiencia", experiencia);

            competenciaExperienciaArray.add(competenciaExperiencia);

            System.out.println("Deseja adicionar outra competencia? (s/n)");
            continuar = teclado.readLine();
        } while ("s".equalsIgnoreCase(continuar));

        JsonObject json = new JsonObject();
        json.addProperty("operacao", "cadastrarCompetenciaExperiencia");
        json.addProperty("email", email);
        json.add("competenciaExperiencia", competenciaExperienciaArray);
        json.addProperty("token", token);

        saida.println(json.toString());
        System.out.println("Dados enviados: " + json.toString());
        saida.flush();
    }

    private static void cadastrarVaga(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email da empresa:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        System.out.println("Digite o titulo da vaga:");
        String nome = teclado.readLine();
        System.out.println("Digite a faixa salarial:");
        String faixaSalarial = teclado.readLine();
        System.out.println("Digite a descricao da vaga:");
        String descricao = teclado.readLine();
        System.out.println("Digite o estado da vaga:");
        String estado = teclado.readLine();

        JsonArray VagaCompetenciaArray = new JsonArray();
        String continuar;

        do {
            JsonObject vagaCompetencia = new JsonObject();
            System.out.println("Digite a competencia:");
            String competencia = teclado.readLine();
            vagaCompetencia.addProperty("competencia", competencia);

            System.out.println("Digite a experiencia:");
            int experiencia = Integer.parseInt(teclado.readLine());
            vagaCompetencia.addProperty("experiencia", experiencia);

            VagaCompetenciaArray.add(vagaCompetencia);

            System.out.println("Deseja exigir outra competencia? (s/n)");
            continuar = teclado.readLine();
        } while ("s".equalsIgnoreCase(continuar));

        JsonObject json = new JsonObject();
        json.addProperty("operacao", "cadastrarVaga");
        json.addProperty("nome", nome);
        json.addProperty("email", email);
        json.addProperty("faixaSalarial", faixaSalarial);
        json.addProperty("descricao", descricao);
        json.addProperty("estado", estado);
        json.add("competencias", VagaCompetenciaArray);
        json.addProperty("token", token);

        saida.println(json.toString());
        System.out.println("Dados enviados: " + json.toString());

        saida.flush();
    }

    //
    private static void visualizarCandidato(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email do usuário:");
        //String email = teclado.readLine();
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        saida.println(criarMensagemJSON("operacao", "visualizarCandidato", "email", email, "token", token));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "visualizarCandidato",
                "email", email,
                "token", token));
        saida.flush();
    }

    private static void visualizarVaga(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email da empresa:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        System.out.println("Digite o id da vaga:");
        String idVaga = teclado.readLine();


        saida.println(criarMensagemJSON("operacao", "visualizarVaga", "email", email,
                "idVaga", idVaga, "token", token));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "visualizarVaga", "email", email,
                "token", token, "idVaga", idVaga));
        saida.flush();
    }

    private static void visualizarCompetenciaExperiencia(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email do usuário:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        saida.println(criarMensagemJSON("operacao", "consultarCompetenciaExperiencia",
                "email", email, "token", token));
        System.out.println("Dados enviados: " +
                criarMensagemJSON("operacao", "consultarCompetenciaExperiencia",
                        "email", email, "token", token));
        saida.flush();
    }


    private static void visualizarEmpresa(PrintWriter saida, BufferedReader teclado) throws IOException {
        // System.out.println("Digite o email da empresa:");
        // String email = teclado.readLine();
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();


        saida.println(criarMensagemJSON("operacao", "visualizarEmpresa",
                "email", email, "token", token));
        System.out.println("Dados enviados: " +
                criarMensagemJSON("operacao", "visualizarEmpresa",
                        "email", email, "token", token));
        saida.flush();

    }

    private static void loginCandidato(PrintWriter saida, BufferedReader teclado, BufferedReader entrada) throws IOException {
        System.out.println("Digite o email do usuário:");
        String email = teclado.readLine();
        System.out.println("Digite a senha:");
        String senha = teclado.readLine();
        saida.println(criarMensagemJSON("operacao", "loginCandidato", "email", email, "senha", senha));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "loginCandidato", "email", email, "senha", senha));


        // Verificar se o login foi bem-sucedido
        //String resposta = entrada.readLine();
        //JSONObject json = new JSONObject(mensagem);

        // Extrai os valores
        //String operacao = json.getString("status");

        //if (respostaJson.getInt("status")==200) {
        //isLoggedIn = true;

        String resposta = entrada.readLine();
        JsonObject respostaJson = JsonParser.parseString(resposta).getAsJsonObject();
        // Aqui você deve verificar a resposta do servidor para ver se o login foi bem-sucedido
        // Se o login foi bem-sucedido, crie a sessão do usuário
        String status = respostaJson.get("status").getAsString();
        String token = respostaJson.get("token").getAsString();
        if ("201".equals(status)) {
            UserSession session = UserSession.getInstance(token, email);
            isLoggedIn = true;
        } else {
            System.out.println("Erro ao fazer login." + respostaJson.get("mensagem").getAsString());
        }
        saida.flush();
    }

    private static void loginEmpresa(PrintWriter saida, BufferedReader teclado, BufferedReader entrada) throws IOException {
        System.out.println("Digite o email da empresa:");
        String email = teclado.readLine();
        System.out.println("Digite a senha:");
        String senha = teclado.readLine();
        saida.println(criarMensagemJSON("operacao", "loginEmpresa", "email", email, "senha", senha));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "loginEmpresa", "email", email, "senha", senha));
        saida.flush();


        //isLoggedIn = true;

        String resposta = entrada.readLine();
        JsonObject respostaJson = JsonParser.parseString(resposta).getAsJsonObject();
        String status = respostaJson.get("status").getAsString();
        String token = respostaJson.get("token").getAsString();
        if ("201".equals(status)) {
            UserSession session = UserSession.getInstance(token, email);
            isLoggedIn = true;
        } else {
            System.out.println("Erro ao fazer login." + respostaJson.get("mensagem").getAsString());
        }


    }


    private static void logout(PrintWriter saida) throws IOException {

        String token = UserSession.getInstance(null, null).getToken();
        saida.println(criarMensagemJSON("operacao", "logout", "token", token));
        //isLoggedIn = false;
        UserSession.getInstance(null, null).cleanUserSession();
        isLoggedIn = false;
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "logout", "token", token));
        saida.flush();

    }


    private static void atualizarCandidato(PrintWriter saida, BufferedReader teclado) throws IOException {

        String token = UserSession.getInstance(null, null).getToken();

        String email = UserSession.getInstance(null, null).getEmail();

        System.out.println("Digite o nome de usuário:");
        String nome = teclado.readLine();
        System.out.println("Digite a senha:");
        String senha = teclado.readLine();
        saida.println(criarMensagemJSON("operacao", "atualizarCandidato", "nome", nome, "email", email, "senha", senha, "token", token));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "atualizarCandidato", "nome", nome, "email", email, "senha", senha, "token", token));
        saida.flush();
    }

    private static void atualizarEmpresa(PrintWriter saida, BufferedReader teclado) throws IOException {
        String token = UserSession.getInstance(null, null).getToken();

        String email = UserSession.getInstance(null, null).getEmail();

        System.out.println("Digite a razao social:");
        String razaoSocial = teclado.readLine();
        System.out.println("Digite o cnpj:");
        String cnpj = teclado.readLine();
        System.out.println("Digite a senha:");
        String senha = teclado.readLine();
        System.out.println("Digite a descricao:");
        String descricao = teclado.readLine();
        System.out.println("Digite o ramo:");
        String ramo = teclado.readLine();


        saida.println(criarMensagemJSON("operacao", "atualizarEmpresa",
                "email", email,
                "razaoSocial", razaoSocial,
                "cnpj", cnpj,
                "senha", senha,
                "descricao", descricao,
                "ramo", ramo));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "atualizarEmpresa",
                "email", email,
                "razaoSocial", razaoSocial,
                "cnpj", cnpj,
                "senha", senha,
                "descricao", descricao,
                "ramo", ramo, "token", token));
        saida.flush();
    }

    private static void atualizarCompetenciaExperiencia(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email do usuário:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        JsonArray competenciaExperienciaArray = new JsonArray();
        String continuar;

        do {
            JsonObject competenciaExperiencia = new JsonObject();
            System.out.println("Digite a competencia:");
            String competencia = teclado.readLine();
            competenciaExperiencia.addProperty("competencia", competencia);

            System.out.println("Digite a experiencia:");
            int experiencia = Integer.parseInt(teclado.readLine());
            competenciaExperiencia.addProperty("experiencia", experiencia);
            competenciaExperienciaArray.add(competenciaExperiencia);

            System.out.println("Deseja alterar outra competencia? (s/n)");
            continuar = teclado.readLine();
        } while ("s".equalsIgnoreCase(continuar));

        JsonObject json = new JsonObject();
        json.addProperty("operacao", "atualizarCompetenciaExperiencia");
        json.addProperty("email", email);
        json.add("competenciaExperiencia", competenciaExperienciaArray);
        json.addProperty("token", token);

        saida.println(json.toString());
        System.out.println("Dados enviados: " + json.toString());
        saida.flush();
    }

    private static void atualizarVaga(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email da empresa:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();
        System.out.println("Digite o titulo da vaga:");
        String nome = teclado.readLine();
        System.out.println("Digite a faixa salarial:");
        String faixaSalarial = teclado.readLine();
        System.out.println("Digite a descricao da vaga:");
        String descricao = teclado.readLine();
        System.out.println("Digite o estado da vaga:");
        String estado = teclado.readLine();

        JsonArray VagaCompetenciaArray = new JsonArray();
        String continuar;

        do {
            JsonObject vagaCompetencia = new JsonObject();
            System.out.println("Digite a competencia:");
            String competencia = teclado.readLine();
            vagaCompetencia.addProperty("competencia", competencia);

            System.out.println("Digite a experiencia:");
            int experiencia = Integer.parseInt(teclado.readLine());
            vagaCompetencia.addProperty("experiencia", experiencia);

            VagaCompetenciaArray.add(vagaCompetencia);

            System.out.println("Deseja exigir outra competencia? (s/n)");
            continuar = teclado.readLine();
        } while ("s".equalsIgnoreCase(continuar));

        JsonObject json = new JsonObject();
        json.addProperty("operacao", "atualizarVaga");
        json.addProperty("nome", nome);
        json.addProperty("email", email);
        json.addProperty("faixaSalarial", faixaSalarial);
        json.addProperty("descricao", descricao);
        json.addProperty("estado", estado);
        json.add("competencias", VagaCompetenciaArray);
        json.addProperty("token", token);

        saida.println(json.toString());
        System.out.println("Dados enviados: " + json.toString());

        saida.flush();
    }


    private static void apagarCandidato(PrintWriter saida, BufferedReader teclado, BufferedReader entrada) throws IOException {
        String token = UserSession.getInstance(null, null).getToken();

        String email = UserSession.getInstance(null, null).getEmail();
        //System.out.println("Digite o nome de nome:");
        //String usuario = teclado.readLine();
        //System.out.println("Digite a senha:");
        //String senha = teclado.readLine();
        saida.println(criarMensagemJSON("operacao", "apagarCandidato", "email", email, "token", token));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "apagarCandidato", "email", email, "token", token));
        saida.flush();

        String resposta = entrada.readLine();
        JsonObject respostaJson = JsonParser.parseString(resposta).getAsJsonObject();
        String status = respostaJson.get("status").getAsString();
        if ("200".equals(status)) {
            logout(saida);
        } else {
            System.out.println("Erro ao apagar candidato." + respostaJson.get("mensagem").getAsString());
        }

    }

    private static void apagarVaga(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o nome de nome:");
        //String usuario = teclado.readLine();

        String token = UserSession.getInstance(null, null).getToken();
        String email = UserSession.getInstance(null, null).getEmail();

        System.out.println("Digite o id da vaga:");
        String idVaga = teclado.readLine();

        saida.println(criarMensagemJSON("operacao", "apagarVaga", "email", email, "idVaga", idVaga, "token", token));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "apagarVaga", "email", email, "idVaga", idVaga, "token", token));
        saida.flush();
    }

    private static void apagarEmpresa(PrintWriter saida, BufferedReader teclado, BufferedReader entrada) throws IOException {

        String token = UserSession.getInstance(null, null).getToken();
        String email = UserSession.getInstance(null, null).getEmail();

        saida.println(criarMensagemJSON("operacao", "apagarEmpresa",
                "email", email, "token", token));
        System.out.println("Dados enviados: " + criarMensagemJSON("operacao", "apagarEmpresa",
                "email", email, "token", token));
        saida.flush();


        String resposta = entrada.readLine();
        JsonObject respostaJson = JsonParser.parseString(resposta).getAsJsonObject();
        String status = respostaJson.get("status").getAsString();
        if ("200".equals(status)) {
            logout(saida);
        } else {
            System.out.println("Erro ao apagar empresa." + respostaJson.get("mensagem").getAsString());
        }
    }

    private static void apagarCompetenciaExperiencia(PrintWriter saida, BufferedReader teclado) throws IOException {
        //System.out.println("Digite o email do usuário:");
        String email = UserSession.getInstance(null, null).getEmail();
        String token = UserSession.getInstance(null, null).getToken();

        JsonArray competenciaExperienciaArray = new JsonArray();
        String continuar;

        do {
            JsonObject competenciaExperiencia = new JsonObject();
            System.out.println("Digite a competencia:");
            String competencia = teclado.readLine();
            competenciaExperiencia.addProperty("competencia", competencia);

            System.out.println("Digite a experiencia:");
            int experiencia = Integer.parseInt(teclado.readLine());
            competenciaExperiencia.addProperty("experiencia", experiencia);
            competenciaExperienciaArray.add(competenciaExperiencia);

            System.out.println("Deseja apagar outra competencia? (s/n)");
            continuar = teclado.readLine();
        } while ("s".equalsIgnoreCase(continuar));

        JsonObject json = new JsonObject();
        json.addProperty("operacao", "apagarCompetenciaExperiencia");
        json.addProperty("email", email);
        json.add("competenciaExperiencia", competenciaExperienciaArray);
        json.addProperty("token", token);

        saida.println(json.toString());
        System.out.println("Dados enviados: " + json.toString());
        saida.flush();
    }

    private static void filtrarVagas(PrintWriter saida, BufferedReader teclado) throws IOException {
        String token = UserSession.getInstance(null, null).getToken();
        // String email = UserSession.getInstance(null, null).getEmail();
        System.out.println("Digite o tipo de filtro OU/E:");
        String tipo = teclado.readLine();

        JsonArray competenciasArray = new JsonArray();
        String continuar;

        do {
            JsonObject competencias = new JsonObject();
            System.out.println("Digite a competencia:");
            String competenciasVagas = teclado.readLine();
            competencias.addProperty("vagas", competenciasVagas);

            System.out.println("Deseja filtrar por mais outra competencia? (s/n)");
            continuar = teclado.readLine();
        } while ("s".equalsIgnoreCase(continuar));


        JsonObject json = new JsonObject();
        json.addProperty("operacao", "filtrarVagas");
        json.addProperty("tipo", tipo);
        json.add("competencias", competenciasArray);
        json.addProperty("token", token);

        saida.println(json.toString());
        System.out.println("Dados enviados: " + json.toString());
        saida.flush();
    }

    private static void listarVagas(PrintWriter saida, BufferedReader teclado) throws IOException {
        String token = UserSession.getInstance(null, null).getToken();
        String email = UserSession.getInstance(null, null).getEmail();

        saida.println(criarMensagemJSON("operacao", "listarVagas", "email", email, "token", token));

    }

}