package server;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CandidatoVagaDAO {

    public void save(CandidatoVaga candidatoVaga) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(candidatoVaga);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void update(CandidatoVaga candidatoVaga) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(candidatoVaga);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void delete(CandidatoVaga candidatoVaga) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.delete(candidatoVaga);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public CandidatoVaga getCandidatoVagaById(int id) {
        Transaction transaction = null;
        CandidatoVaga candidatoVaga = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            candidatoVaga = session.get(CandidatoVaga.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return candidatoVaga;
    }

    public CandidatoVaga getCandidatoVagaByIdCandidato(int idCandidato) {
        Transaction transaction = null;
        CandidatoVaga candidatoVaga = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            candidatoVaga = session.createQuery("FROM CandidatoVaga WHERE idCandidato = :idCandidato", CandidatoVaga.class)
                    .setParameter("idCandidato", idCandidato)
                    .uniqueResult();

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return candidatoVaga;
    }

    public CandidatoVaga getCandidatoVagaByIdVaga(int idVaga) {
        Transaction transaction = null;
        CandidatoVaga candidatoVaga = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            candidatoVaga = session.createQuery("FROM CandidatoVaga WHERE idVaga = :idVaga", CandidatoVaga.class)
                    .setParameter("idVaga", idVaga)
                    .uniqueResult();

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return candidatoVaga;
    }



}
