package server;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CandidatoCompetenciaDAO {

    public void save(CandidatoCompetencia candidatoCompetencia) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(candidatoCompetencia);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void update(CandidatoCompetencia candidatoCompetencia) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(candidatoCompetencia);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void delete(CandidatoCompetencia candidatoCompetencia) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.delete(candidatoCompetencia);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();

        }
    }

    public CandidatoCompetencia getCandidatoCompetenciaById(int id) {
        Transaction transaction = null;
        CandidatoCompetencia candidatoCompetencia = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            candidatoCompetencia = session.get(CandidatoCompetencia.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();

        }
        return candidatoCompetencia;
    }

    public CandidatoCompetencia getCandidatoCompetenciaByCandidatoId(int id) {
        Transaction transaction = null;
        CandidatoCompetencia candidatoCompetencia = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            candidatoCompetencia = session.createQuery("FROM CandidatoCompetencia WHERE candidato_id = :id", CandidatoCompetencia.class)
                    .setParameter("id", id)
                    .uniqueResult();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();

        }
        return candidatoCompetencia;
    }

    public CandidatoCompetencia getCandidatoCompetenciaByCompetenciaId(int id) {
        Transaction transaction = null;
        CandidatoCompetencia candidatoCompetencia = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            candidatoCompetencia = session.createQuery("FROM CandidatoCompetencia WHERE competencia_id = :id", CandidatoCompetencia.class)
                    .setParameter("id", id)
                    .uniqueResult();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();

        }
        return candidatoCompetencia;
    }



}