package server;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class VagaCompetenciaDAO {

    public void save(VagaCompetencia vagaCompetencia) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(vagaCompetencia);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();

        }
    }

    public void update(VagaCompetencia vagaCompetencia) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(vagaCompetencia);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void delete(VagaCompetencia vagaCompetencia) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.delete(vagaCompetencia);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public VagaCompetencia getVagaCompetenciaById(int id) {
        Transaction transaction = null;
        VagaCompetencia vagaCompetencia = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            vagaCompetencia = session.get(VagaCompetencia.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return vagaCompetencia;
    }

    public VagaCompetencia getVagaCompetenciaByVagaId(int id) {
        Transaction transaction = null;
        VagaCompetencia vagaCompetencia = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            vagaCompetencia = session.get(VagaCompetencia.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return vagaCompetencia;
    }

    public VagaCompetencia getVagaCompetenciaByCompetenciaId(int id) {
        Transaction transaction = null;
        VagaCompetencia vagaCompetencia = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            vagaCompetencia = session.get(VagaCompetencia.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return vagaCompetencia;
    }




}
